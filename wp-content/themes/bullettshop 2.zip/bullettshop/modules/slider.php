<div id="slide-case" class="row slide-case">
  <ul data-orbit data-options="animation:fade; bullets: false; slide_number: false; timer: false;">
    <li>
      <img src="<?php echo ot_get_option( 'home_page_featured_slider' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
    </li>
    <li>
      <img src="<?php echo ot_get_option( 'slide_2' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
    </li>
    <li>
      <img src="<?php echo ot_get_option( 'home_page_featured_slider' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
    </li>
  </ul>
</div>