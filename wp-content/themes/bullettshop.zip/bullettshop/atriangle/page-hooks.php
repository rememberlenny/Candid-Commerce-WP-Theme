<?php

function atr_header_post() {
    do_action('atr_header_post');
}
function atr_footer_pre() {
    do_action('atr_footer_pre');
}

?>